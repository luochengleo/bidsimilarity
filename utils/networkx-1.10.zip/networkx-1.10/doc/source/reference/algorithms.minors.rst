******
Minors
******

.. automodule:: networkx.algorithms.minors
.. autosummary::
   :toctree: generated/

   contracted_edge
   contracted_nodes
   identified_nodes
   quotient_graph
