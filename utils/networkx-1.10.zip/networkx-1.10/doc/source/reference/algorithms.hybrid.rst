******
Hybrid
******

.. automodule:: networkx.algorithms.hybrid
.. autosummary::
   :toctree: generated/

   kl_connected_subgraph
   is_kl_connected
